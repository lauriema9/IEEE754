
public class RegularPay extends PayCalculator {
     public RegularPay(double payRate){
    	 super.payRate = payRate;
     }

}
